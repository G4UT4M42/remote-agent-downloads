REMOTE AGENT 2.6.35 ? EMERGENCY BETA WINDOWS INSTALLER

Emergency/manual distribution while official /downloads/windows endpoint
is unavailable. Source commit: b3deb787788e2d94402e069247e9198c4cc2e7f2.
This is a current-user installation, not a Windows service auto-update.

HOW TO INSTALL
1. Extract ALL files from this ZIP into a new empty folder.
2. Double-click Install-RemoteAgent.cmd in that folder.
3. Follow the browser device-pairing instructions displayed by the installer.
   A signed-in Remote Agent account and an active Internet connection are required.
4. Do NOT use the old 2.6.6 installer. Do NOT run as SYSTEM.
5. For existing background-service or dual-mode clients: DO NOT run this
   current-user installer over them. Wait for a qualified service update.

INTEGRITY
Embedded remote-agent-2.6.35.zip SHA-256:
538c11ffc70ed26f7744101e74e5abe4b3ddd55c937b86cf88d41f5aec2f31df

The installer verifies this hash, package bytes, ZIP member hashes,
provenance and installation preflight before using the package.
The existing browser pairing remains on mcp.remote-agent.ai.

THIS BETA BUNDLE IS NOT A SIGNED PRODUCT AUTO-UPDATE.
Verify its outer SHA-256 from the independently published announcement.
Only download from the project owner. It is not proof that the public official
download endpoint has been repaired.
