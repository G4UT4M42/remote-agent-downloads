@echo off
setlocal
set "RA_DIR=%~dp0"
echo Remote Agent 2.6.35 - Emergency Beta Installer
echo This installer pairs with https://mcp.remote-agent.ai
echo It installs only for the current Windows user. Do not run as SYSTEM.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%RA_DIR%install.ps1" -ManifestPath "%RA_DIR%manifest.json" -LocalPackagePath "%RA_DIR%remote-agent-2.6.35.zip"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Installation exited with error code %RC%.
pause
exit /b %RC%
