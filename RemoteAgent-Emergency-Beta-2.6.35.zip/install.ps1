param(
    [Parameter(Mandatory=$true)][string]$ManifestPath,
    [Parameter(Mandatory=$true)][string]$LocalPackagePath,
    [string]$InstallDir = '',
    [string]$DeviceName = [Environment]::MachineName
)
$ErrorActionPreference = 'Stop'
$env:PSModulePath = (Join-Path $PSHOME 'Modules') + [IO.Path]::PathSeparator + $env:PSModulePath
$env:PYTHONDONTWRITEBYTECODE = '1'
$ProgressPreference = 'SilentlyContinue'

$Product = 'Remote Agent'
$Origin = 'https://mcp.remote-agent.ai'
$manifest = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$ExpectedVersion = [string]$manifest.version
if ($ExpectedVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid release version.' }

function Fail([string]$Message) {
    throw ('REMOTE_AGENT_INSTALL_FAILED: ' + $Message)
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { Fail 'Windows is required.' }
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
if ($identity.User.Value -in @('S-1-5-18','S-1-5-19','S-1-5-20')) {
    Fail 'Run this installer as the Windows user who will use Remote Agent.'
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Keep an existing managed pilot installation in place. Fresh installs use LOCALAPPDATA.
if (-not $InstallDir) {
    $legacyTask = 'SharpinRemoteAgent-User-' + $identity.User.Value
    $task = Get-ScheduledTask -TaskName $legacyTask -ErrorAction SilentlyContinue
    if ($task -and $task.Actions.Count -eq 1) {
        $candidate = [string]$task.Actions[0].WorkingDirectory
        if ($candidate -and (Test-Path -LiteralPath (Join-Path $candidate 'config.json')) -and
            (Test-Path -LiteralPath (Join-Path $candidate 'PACKAGE-MANIFEST.json'))) {
            $InstallDir = $candidate
        }
    }
    if (-not $InstallDir) { $InstallDir = Join-Path $env:LOCALAPPDATA 'Remote Agent' }
}
$InstallDir = [IO.Path]::GetFullPath($InstallDir).TrimEnd('\')

function Download-File([string]$Url, [string]$Destination) {
    if (-not $Url.StartsWith($Origin + '/', [StringComparison]::OrdinalIgnoreCase)) {
        Fail 'Download URL is outside the Remote Agent origin.'
    }
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destination -MaximumRedirection 0 -TimeoutSec 600
}

function Read-Json([string]$Path) {
    return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json)
}

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

$mutex = New-Object Threading.Mutex($false, ('Local\RemoteAgentInstaller-' + $identity.User.Value))
try { $locked = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $locked = $true }
if (-not $locked) { $mutex.Dispose(); Fail 'Another Remote Agent installer is already running. Return to that window.' }
$work = Join-Path $env:TEMP ('RemoteAgentInstall-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work -ErrorAction Stop | Out-Null
$acl = New-Object Security.AccessControl.DirectorySecurity
$acl.SetOwner($identity.User)
$acl.SetAccessRuleProtection($true, $false)
$acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($identity.User, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
Set-Acl -LiteralPath $work -AclObject $acl
$requestFile = Join-Path $work 'request.json'
$packageFile = Join-Path $work 'remote-agent.zip'
$payloadDir = Join-Path $work 'payload'

function Get-BrowserEnrollment {
    Write-Host '[3/5] Confirm this PC in your browser.'
    $body = @{ device_name = $DeviceName } | ConvertTo-Json -Compress
    $reply = Invoke-WebRequest -UseBasicParsing -MaximumRedirection 0 -TimeoutSec 30 -Method Post -Uri ($Origin + '/api/installer/pair/start') -ContentType 'application/json' -Body $body
    $pair = $reply.Content | ConvertFrom-Json
    if ($pair.device_code -notmatch '^[A-Za-z0-9_-]{43}$' -or $pair.user_code -notmatch '^[A-Z2-9]{4}-[A-Z2-9]{4}$' -or $pair.expires_in -lt 30 -or $pair.expires_in -gt 900) { Fail 'Invalid pairing response.' }
    $url = $Origin + '/connect/windows?code=' + $pair.user_code
    if ($pair.verification_uri_complete -ne $url) { Fail 'Invalid browser verification URL.' }
    Write-Host ('Pairing code: ' + $pair.user_code)
    Write-Host ('Browser link: ' + $url)
    Write-Host 'Sign in and confirm only when the computer name and code match.'
    try { Start-Process -FilePath $url -ErrorAction Stop | Out-Null }
    catch { Write-Host 'The browser could not be opened. Open the link above on this PC or your phone.' }
    $deadline = [DateTime]::UtcNow.AddSeconds([int]$pair.expires_in)
    $pollBody = @{ device_code = $pair.device_code } | ConvertTo-Json -Compress
    $networkFailures = 0
    do {
        Start-Sleep -Seconds 5
        try {
            $reply = Invoke-WebRequest -UseBasicParsing -MaximumRedirection 0 -TimeoutSec 20 -Method Post -Uri ($Origin + '/api/installer/pair/poll') -ContentType 'application/json' -Body $pollBody
        } catch {
            $status = 0
            if ($_.Exception.Response) { $status = [int]$_.Exception.Response.StatusCode }
            if ($status -eq 403) { Fail 'Pairing was cancelled. No device was enrolled.' }
            if ($status -eq 410) { Fail 'Pairing expired or was already used. Run the installer again.' }
            if ($status -eq 429) { Start-Sleep -Seconds 5; continue }
            $networkFailures++
            if ($networkFailures -gt 5) { Fail 'Could not reach the pairing service. Run the installer again.' }
            continue
        }
        $networkFailures = 0
        $result = $reply.Content | ConvertFrom-Json
        if ($result.status -eq 'approved') {
            if ($result.device_name -ne $DeviceName -or $result.enrollment_token -notmatch '^[a-f0-9]{64}$') { Fail 'Pairing response does not match this device.' }
            return [string]$result.enrollment_token
        }
        if ($result.status -ne 'authorization_pending') { Fail 'Unexpected pairing response.' }
    } while ([DateTime]::UtcNow -lt $deadline)
    Fail 'Pairing was not confirmed in time. Run the installer again.'
}

function Write-PrivateRequest([string]$Token) {
    $request = [ordered]@{ enrollment_token = $Token; relay_url = $Origin; device_name = $DeviceName; excluded_paths = @() }
    [IO.File]::WriteAllText($requestFile, ($request | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
    $acl = New-Object Security.AccessControl.FileSecurity
    $acl.SetOwner($identity.User)
    $acl.SetAccessRuleProtection($true, $false)
    $rule = New-Object Security.AccessControl.FileSystemAccessRule($identity.User, 'FullControl', 'Allow')
    $acl.AddAccessRule($rule)
    Set-Acl -LiteralPath $requestFile -AclObject $acl
}

function Run-Managed([string[]]$Arguments) {
    & (Join-Path $PSHOME 'powershell.exe') -NoLogo -NoProfile -ExecutionPolicy Bypass -File $installer -AgentDir $InstallDir -PayloadDir $payloadDir @Arguments
    if ($LASTEXITCODE -ne 0) { Fail 'Managed installation failed. See Remote Agent Installer Logs in LOCALAPPDATA.' }
}

try {
    if ($manifest.schema_version -ne 2 -or $manifest.format -ne 'managed-source' -or $manifest.product -ne $Product -or
        $manifest.version -ne $ExpectedVersion -or $manifest.channel -ne 'pilot') {
        Fail 'Installation manifest is invalid.'
    }
    if ($manifest.package_url -ne ('local-package:remote-agent-' + $ExpectedVersion + '.zip')) {
        Fail 'Package URL is not the expected Remote Agent URL.'
    }
    if ([string]$manifest.package_sha256 -notmatch '^[a-f0-9]{64}$') {
        Fail 'Package hash is invalid.'
    }

    Write-Host ('[1/5] Downloading ' + $Product + ' ' + $ExpectedVersion + '...')
    if (-not (Test-Path -LiteralPath $LocalPackagePath -PathType Leaf)) { Fail 'Local release file missing.' }
    Copy-Item -LiteralPath $LocalPackagePath -Destination $packageFile -ErrorAction Stop
    if ((Get-Sha256 $packageFile) -ne [string]$manifest.package_sha256) {
        Fail 'Downloaded package hash does not match the manifest.'
    }
    if ((Get-Item -LiteralPath $packageFile).Length -ne [int64]$manifest.package_bytes) {
        Fail 'Downloaded package size does not match the manifest.'
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [IO.Compression.ZipFile]::OpenRead($packageFile)
    try {
        $seen = @{}
        $totalBytes = [int64]0
        if ($archive.Entries.Count -gt 256) { Fail 'Package has too many entries.' }
        foreach ($entry in $archive.Entries) {
            $totalBytes += $entry.Length
            if ($entry.Length -gt 67108864 -or $totalBytes -gt 536870912) { Fail 'Package exceeds extraction limits.' }
            $name = [string]$entry.FullName
            if (-not $name -or $name.StartsWith('/') -or $name.StartsWith('.') -or
                $name.Contains('\') -or $name.Contains('/') -or $name.Contains(':') -or
                $seen.ContainsKey($name) -or $entry.Name -ne $name) {
                Fail 'Package contains an invalid path.'
            }
            $seen[$name] = $true
        }
    } finally {
        $archive.Dispose()
    }

    New-Item -ItemType Directory -Path $payloadDir -ErrorAction Stop | Out-Null
    [IO.Compression.ZipFile]::ExtractToDirectory($packageFile, $payloadDir)

    $packageManifestPath = Join-Path $payloadDir 'PACKAGE-MANIFEST.json'
    if (-not (Test-Path -LiteralPath $packageManifestPath -PathType Leaf)) {
        Fail 'Package manifest is missing.'
    }
    $packageManifest = Read-Json $packageManifestPath
    if ($packageManifest.schema_version -ne 2 -or
        $packageManifest.agent_version -ne $ExpectedVersion -or
        $packageManifest.distribution -ne 'source-manual-deployment' -or
        $packageManifest.automatic_update -ne $false -or
        $packageManifest.source_clean -ne $true) {
        Fail 'Package provenance is not a clean Remote Agent release.'
    }

    $expectedFiles = @{}
    foreach ($entry in $packageManifest.files) {
        $name = [string]$entry.path
        if (-not $seen.ContainsKey($name) -or $expectedFiles.ContainsKey($name)) {
            Fail 'Package inventory does not match its manifest.'
        }
        $file = Join-Path $payloadDir $name
        if (-not (Test-Path -LiteralPath $file -PathType Leaf) -or
            (Get-Item -LiteralPath $file).Length -ne [int64]$entry.size -or
            (Get-Sha256 $file) -ne [string]$entry.sha256) {
            Fail ('Package file verification failed: ' + $name)
        }
        $expectedFiles[$name] = $true
    }
    if ($seen.Count -ne ($expectedFiles.Count + 1) -or -not $seen.ContainsKey('PACKAGE-MANIFEST.json')) {
        Fail 'Package contains unlisted files.'
    }

    $existingConfig = Test-Path -LiteralPath (Join-Path $InstallDir 'config.json') -PathType Leaf
    $installer = Join-Path $payloadDir 'install_managed_user.ps1'
    Run-Managed @('-Phase', 'Preflight')
    Write-Host '[2/5] Installing private Python, packages and Chromium. This may take several minutes.'
    if ($existingConfig) {
        Write-Host 'Existing installation found. Keeping this device identity and access settings.'
        if (-not (Test-Path -LiteralPath (Join-Path $InstallDir 'state.json'))) {
            $cfg = Read-Json (Join-Path $InstallDir 'config.json')
            if ($cfg.relay_url -ne $Origin) { Fail 'Pending installation belongs to a different server.' }
            $DeviceName = [string]$cfg.device_name
            Run-Managed @('-Phase', 'Pause')
            Write-Host 'Finishing an interrupted installation. Confirm a fresh pairing request.'
            $pendingRuntime = Read-Json (Join-Path $InstallDir 'runtime\active-runtime.json')
            $pendingPython = [string]$pendingRuntime.python
            $token = Get-BrowserEnrollment
            Write-PrivateRequest $token
            $token = $null
            & $pendingPython (Join-Path $payloadDir 'installer_resume.py') --agent-dir $InstallDir --input-file $requestFile
            if ($LASTEXITCODE -ne 0) { Fail 'Pending enrollment could not be refreshed safely.' }
        } else {
            Write-PrivateRequest 'existing-installation-preserves-current-identity'
        }
        Run-Managed @('-Phase', 'Install', '-InputFile', $requestFile)
    } else {
        Run-Managed @('-Phase', 'Prepare')
    }
    $runtime = Read-Json (Join-Path $InstallDir 'runtime\active-runtime.json')
    $python = [IO.Path]::GetFullPath([string]$runtime.python)
    if (-not $python.StartsWith((Join-Path $InstallDir 'runtime') + '\', [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $python -PathType Leaf)) { Fail 'Private Python runtime is invalid.' }
    & $python (Join-Path $InstallDir 'installer_smoke.py')
    if ($LASTEXITCODE -ne 0) { Fail 'Python or Chromium functional check failed. Run the installer again to retry.' }
    if (-not $existingConfig) {
        $token = Get-BrowserEnrollment
        Write-PrivateRequest $token
        $token = $null
        Write-Host '[4/5] Saving the confirmed device and enabling user startup.'
        Run-Managed @('-Phase', 'Initialize', '-InputFile', $requestFile)
        Run-Managed @('-Phase', 'Startup')
    }
    $env:SHARPIN_AGENT_CONFIG = Join-Path $InstallDir 'config.json'
    $env:SHARPIN_AGENT_STATE = Join-Path $InstallDir 'state.json'
    Write-Host '[5/5] Verifying enrollment and authenticated server connection.'

    $runtimeState = Join-Path $InstallDir 'runtime\active-runtime.json'
    $agentPath = Join-Path $InstallDir 'agent.py'
    $deadline = [DateTime]::UtcNow.AddSeconds(90)
    $verified = $null
    do {
        if ((Test-Path -LiteralPath $runtimeState -PathType Leaf) -and
            (Test-Path -LiteralPath $agentPath -PathType Leaf)) {
            try {
                $runtime = Read-Json $runtimeState
                $python = [string]$runtime.python
                if ($python -and (Test-Path -LiteralPath $python -PathType Leaf)) {
                    $rawStatus = (& $python $agentPath --test-connection 2>$null | Out-String).Trim()
                    if ($LASTEXITCODE -eq 0 -and $rawStatus) {
                        $candidate = $rawStatus | ConvertFrom-Json
                        if ($candidate.version -eq $ExpectedVersion -and
                            $candidate.enrolled -eq $true -and
                            $candidate.connection_test -eq 'ok' -and
                            $candidate.relay_url -eq $Origin) {
                            $verified = $candidate
                            break
                        }
                    }
                }
            } catch {
                # The startup task may still be completing enrollment.
            }
        }
        Start-Sleep -Seconds 2
    } while ([DateTime]::UtcNow -lt $deadline)

    if (-not $verified) {
        Fail 'Installation completed locally, but enrollment/connection was not confirmed within 90 seconds.'
    }

    & $python (Join-Path $InstallDir 'installer_verify.py')
    if ($LASTEXITCODE -ne 0) { Fail 'The server did not accept the saved device credential.' }
    Write-Host ''
    Write-Host ($Product + ' ' + $verified.version + ' is installed and connected.')
    Write-Host ('Device: ' + $verified.device_name)
    Write-Host ('Server: ' + $verified.relay_url)
    Write-Host ('Install directory: ' + $InstallDir)
    Write-Host 'Credentials were not printed.'
} finally {
    if (Test-Path -LiteralPath $requestFile) {
        Remove-Item -LiteralPath $requestFile -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path -LiteralPath $work) {
        Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
    }
    if ($locked) { $mutex.ReleaseMutex() }; $mutex.Dispose()
}
